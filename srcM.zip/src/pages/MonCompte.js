const MonCompte=()=>{
    return(
        <div>
            <h1>Mon compte</h1>
        </div>
    )
}
export default MonCompte;