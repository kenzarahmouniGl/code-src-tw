const Fleurs=()=>{
    return(
        <div>
            <h1>Les fleurs</h1>
        </div>
    )
}
export default Fleurs;